﻿using System; // For basic system functions like DateTime
using System.Collections.Generic; // For using collections like List
using System.ComponentModel.DataAnnotations; // For data validation attributes
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProgPoe.Models; // For accessing the Document model

namespace ClaimsApp_Test
{
    [TestFixture] // Indicates this class contains test methods
    public class DocumentModelTest
    {
        [Test] // Denotes a test method
        public void Document_ValidProperties_ValidDocument()
        {
            // Create a valid Document object with all required fields properly set
            var document = new Document
            {
                DocumentName = "Test Document", // Valid document name
                FilePath = "C:/Users/lab_services_student/source/repos/ProgPoe/wwwroot/SupportingDocuments/c62ee4d7-c7c8-4f0b-9317-b6d6b7435f80_lorem facts.pdf", // Valid file path
                UploadedOn = DateTime.Now, // Current date and time as upload time
                ClaimId = 1 // Valid claim ID
            };

            // Validate the document object and ensure no validation errors
            var validationResults = ValidateModel(document);
            Assert.IsEmpty(validationResults); // Assert that there are no validation errors
        }

        [Test] // Denotes a test method
        public void Document_EmptyDocumentName_InvalidDocumentName()
        {
            // Create a Document object with an empty DocumentName to trigger validation error
            var document = new Document
            {
                DocumentName = string.Empty, // Invalid empty document name
                FilePath = "C:/Users/lab_services_student/source/repos/ProgPoe/wwwroot/SupportingDocuments/c62ee4d7-c7c8-4f0b-9317-b6d6b7435f80_lorem facts.pdf",
                UploadedOn = DateTime.Now,
                ClaimId = 1
            };

            // Validate the document object
            var validationResults = ValidateModel(document);

            // Assert that validation failed and returned an error for the empty DocumentName
            Assert.IsNotEmpty(validationResults);
            Assert.AreEqual("Document Name is required.", validationResults[0].ErrorMessage);
        }

        [Test] // Denotes a test method
        public void Document_EmptyFilePath_InvalidDocumentFilePath()
        {
            // Create a Document object with an empty FilePath to trigger validation error
            var document = new Document
            {
                DocumentName = "Test Document", // Valid document name
                FilePath = string.Empty, // Invalid empty file path
                UploadedOn = DateTime.Now,
                ClaimId = 1
            };

            // Validate the document object
            var validationResults = ValidateModel(document);

            // Assert that validation failed and returned an error for the empty FilePath
            Assert.IsNotEmpty(validationResults);
            Assert.AreEqual("File Path is required.", validationResults[0].ErrorMessage);
        }

        [Test] // Denotes a test method
        public void Document_ExceededDocumentNameMaxLength_ShouldBeInvalid()
        {
            // Create a Document object with a DocumentName that exceeds the maximum allowed length
            var document = new Document
            {
                DocumentName = new string('A', 256), // Invalid document name with 256 characters (exceeds the limit of 255)
                FilePath = "C:/Users/lab_services_student/Documents/TestDocument.pdf",
                UploadedOn = DateTime.Now,
                ClaimId = 1
            };

            // Validate the document object
            var validationResults = ValidateModel(document);

            // Assert that validation failed due to the exceeded maximum length of DocumentName
            Assert.IsNotEmpty(validationResults);
            Assert.AreEqual("The field DocumentName must be a string or array type with a maximum length of '255'.", validationResults[0].ErrorMessage);
        }

        // Helper method to validate the Document model and return validation results
        private IList<ValidationResult> ValidateModel(Document document)
        {
            var validationResults = new List<ValidationResult>(); // List to store validation results
            var validationContext = new ValidationContext(document); // Context for validating the document object
            Validator.TryValidateObject(document, validationContext, validationResults, true); // Perform validation
            return validationResults; // Return the list of validation results
        }
    }
}
