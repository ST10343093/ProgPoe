﻿using Microsoft.AspNetCore.Http; // For handling HTTP requests and responses
using Microsoft.AspNetCore.Identity; // For user management and authentication
using Microsoft.EntityFrameworkCore; // For database interactions using Entity Framework Core
using Moq; // For mocking dependencies in unit tests
using ProgPoe.Controllers; // The namespace containing the ClaimController
using System; // For basic system functions like Guid and exceptions
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProgPoe.Data; // For accessing the application database context

namespace ClaimsApp_Test
{
    [TestFixture] // Denotes a test class
    public class ClaimControllerTests
    {
        private ClaimController _controller; // The controller being tested
        private ApplicationDbContext _context; // The in-memory database context for tests
        private UserManager<IdentityUser> _userManager; // For managing Identity users
        private IdentityUser _testUser; // A test user for the application

        [SetUp]
        public void Setup()
        {
            // Setting up an in-memory database for testing
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase" + Guid.NewGuid().ToString()) // Using a unique database name to isolate each test
                .Options;

            _context = new ApplicationDbContext(options); // Initializing the context
            _userManager = CreateUserManager(); // Creating a mock UserManager

            // Creating a test user
            _testUser = new IdentityUser
            {
                Id = Guid.NewGuid().ToString(), // Assigning a unique ID
                UserName = "testuser@example.com" // Assigning a test username
            };

            // Adding the test user to the database
            _context.Users.Add(_testUser);
            _context.SaveChanges();

            // Initializing the controller with dependencies
            _controller = new ClaimController(_context, _userManager, null);
        }

        [TearDown]
        public void Dispose()
        {
            // Cleaning up resources after each test
            _context?.Dispose();
            _controller?.Dispose();
            _userManager?.Dispose();
        }

        [Test]
        public void IsValidPdfDocument_ValidPdf_ReturnsTrue()
        {
            // Creating a valid PDF file
            var validFile = new FormFile(new MemoryStream(new byte[100]), 0, 100, "Data", "valid.pdf")
            {
                Headers = new HeaderDictionary(), // Setting empty headers
                ContentType = "application/pdf" // Specifying the correct content type
            };

            // Calling the method to check if the document is valid
            var result = _controller.IsValidDocument(validFile);
            Assert.IsTrue(result); // Asserting that a valid PDF returns true
        }

        [Test]
        public void IsValidPdfDocument_InvalidPdf_ReturnsFalse()
        {
            // Creating an invalid PDF file (incorrect content type)
            var invalidFile = new FormFile(new MemoryStream(new byte[100]), 0, 100, "Data", "invalid.txt")
            {
                Headers = new HeaderDictionary(),
                ContentType = "text/plain" // Incorrect content type (text instead of PDF)
            };

            // Calling the method to check if the document is valid
            var result = _controller.IsValidDocument(invalidFile);
            Assert.IsFalse(result); // Asserting that an invalid PDF returns false
        }

        [Test]
        public void IsValidPdfDocument_FileTooLarge_ReturnsFalse()
        {
            // Creating a large PDF file that exceeds the size limit
            var largeFile = new FormFile(new MemoryStream(new byte[20 * 1024 * 1024]), 0, 20 * 1024 * 1024, "Data", "large.pdf")
            {
                Headers = new HeaderDictionary(),
                ContentType = "application/pdf" // Correct content type but file is too large
            };

            // Calling the method to check if the document is valid
            var result = _controller.IsValidDocument(largeFile);
            Assert.IsFalse(result); // Asserting that a large file returns false
        }

        // Helper method to create a mock UserManager for testing purposes
        private UserManager<IdentityUser> CreateUserManager()
        {
            var store = new Mock<IUserStore<IdentityUser>>(); // Mocking the IUserStore
            var userManager = new UserManager<IdentityUser>(
                store.Object, // Passing the mock store
                null, // Other parameters can be null since they are not needed for this test
                null,
                null,
                null,
                null,
                null,
                null,
                null
            );

            return userManager;
        }
    }
}
