﻿using System; // For basic system functions like DateTime
using System.Collections.Generic; // For using collections such as List
using System.ComponentModel.DataAnnotations; // For data validation attributes
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProgPoe.Models; // For accessing the Claim model
namespace ClaimsApp_Test
{
    [TestFixture] // Denotes a test class
    public class ClaimModelTest
    {
        [Test]
        public void Claim_WithInvalidHoursWorked_HasValidationErrors()
        {
            // Creating a claim with invalid HoursWorked (0 hours)
            var claim = new Claim
            {
                HoursWorked = 0, // Invalid value, should trigger validation error
                HourlyRate = 100,
                TotalAmount = 1000,
                Notes = "Invalid claim due to hours worked.",
                DateSubmitted = DateTime.Now
            };

            // List to store validation results
            var validationResults = new List<ValidationResult>();

            // ValidationContext for the claim object
            var validationContext = new ValidationContext(claim);

            // Validate the claim object
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert that validation fails
            Assert.IsFalse(isValid);
            Assert.IsNotEmpty(validationResults);

            // Assert that the correct validation error message is returned
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Hours Worked must be between 1 and 100."));
        }

        [Test]
        public void ValidClaim_NoValidationErrors()
        {
            // Creating a valid claim object
            var claim = new Claim
            {
                HoursWorked = 10, // Valid value
                HourlyRate = 200,
                TotalAmount = 1000,
                Notes = "This is a valid claim.",
                DateSubmitted = DateTime.Now
            };

            // List to store validation results
            var validationResults = new List<ValidationResult>();

            // ValidationContext for the claim object
            var validationContext = new ValidationContext(claim);

            // Validate the claim object
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert that validation passes
            Assert.IsTrue(isValid);
            Assert.IsEmpty(validationResults); // Ensure no validation errors are returned
        }

        [Test]
        public void Claim_WithIncorrectHourlyRate_ShouldHaveValidationErrors()
        {
            // Creating a claim with an invalid HourlyRate (below allowed range)
            var claim = new Claim
            {
                HoursWorked = 10,
                HourlyRate = 40, // Invalid value, should trigger validation error
                TotalAmount = 400,
                Notes = "Invalid claim due to hourly rate.",
                DateSubmitted = DateTime.Now
            };

            // List to store validation results
            var validationResults = new List<ValidationResult>();

            // ValidationContext for the claim object
            var validationContext = new ValidationContext(claim);

            // Validate the claim object
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert that validation fails
            Assert.IsFalse(isValid);
            Assert.IsNotEmpty(validationResults);

            // Assert that the correct validation error message is returned
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Hourly Rate must be between 50 and 1000."));
        }

        [Test]
        public void Claim_WithFutureDateSubmitted_CorrectValidationErrors()
        {
            // Creating a claim with a future submission date
            var claim = new Claim
            {
                HoursWorked = 10,
                HourlyRate = 100,
                TotalAmount = 1000,
                Notes = "This claim has a future submission date.",
                DateSubmitted = DateTime.Now.AddDays(1) // Date is in the future
            };

            // List to store validation results
            var validationResults = new List<ValidationResult>();

            // ValidationContext for the claim object
            var validationContext = new ValidationContext(claim);

            // Validate the claim object
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert that validation fails
            Assert.IsFalse(isValid);
            Assert.IsNotEmpty(validationResults);

            // Assert that the correct validation error message is returned
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Date Submitted cannot be in the future."));
        }

        [Test]
        public void Claim_WithDateNotInCurrentOrPreviousMonth_CorrectValidationErrors()
        {
            // Creating a claim with a date not in the current or previous month
            var claim = new Claim
            {
                HoursWorked = 10,
                HourlyRate = 100,
                TotalAmount = 1000,
                Notes = "Invalid submission date.",
                DateSubmitted = new DateTime(DateTime.Now.Year, DateTime.Now.Month - 2, 1) // Date is more than a month old
            };

            // List to store validation results
            var validationResults = new List<ValidationResult>();

            // ValidationContext for the claim object
            var validationContext = new ValidationContext(claim);

            // Validate the claim object
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert that validation fails
            Assert.IsFalse(isValid);
            Assert.IsNotEmpty(validationResults);

            // Assert that the correct validation error message is returned
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Date Submitted can
